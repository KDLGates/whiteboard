from setuptools import setup

setup(
    name='whiteboard',
    packages=['whiteboard'],
    include_package_data=True,
    install_requires=[
        'flask',
    ],
)